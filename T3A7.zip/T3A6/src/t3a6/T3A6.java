/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package t3a6;

/**
 *
 * @author ioann
 */
import java.util.Scanner;
public class T3A6 {

    
    public static void main(String[] args) {
        ejercicio1 ();
        ejercicio2 ();
        ejercicio3 ();
        ejercicio4 ();
        
        
    }
    
    
    public static void ejercicio1 (){
        //Solicitar una cantidad determinada de números secuenciales y calcular la suma total de estos.
        Scanner obj=new Scanner (System.in);
            System.out.println("Inicio: ");
            int opcion=0;
            int inicio = obj.nextInt();
            
            System.out.println("Limite: ");
            int limite = obj.nextInt();
            
            System.out.println("Incremento: ");
            int incremento = obj.nextInt();
            opcion=inicio + incremento;
            
            if (inicio < limite ){
                for (int numero=inicio; numero <= limite; numero +=incremento){
                    System.out.println("Numero actual es " + numero);
                  
                }  System.out.println("la suma total de los numeors es de" + opcion);
            }else if (limite < inicio){
                for (int numero = inicio; numero >= limite; numero -= incremento){
                    System.out.println("Numero actual es " + numero);
                } System.out.println("la suma total de los numeors es de" + opcion);
            }else{
                System.out.println("El inicio es identico al limite " + inicio + "-" + limite);
            }
    }
    
    
    public static void ejercicio2 (){
        //Pedir los primero 10 números impares y calcular el producto.
        Scanner obj=new Scanner (System.in);
        
        System.out.println("bienvenido , por favor escriba los  primeros 10 numeoros impares para realizar la suma");
        int num1=obj.nextInt();
        int num2=obj.nextInt();
        int num3=obj.nextInt();
        int num4=obj.nextInt();
        int num5=obj.nextInt();
        int num6=obj.nextInt();
        int num7=obj.nextInt();
        int num8=obj.nextInt();
        int num9=obj.nextInt();
        int num10=obj.nextInt();
        
        if ((num1%2)!=0 && (num2%2)!=0 && (num3%2)!=0 && (num4%2)!=0 && (num5%2)!=0 && (num6%2)!=0 && (num7%2)!=0 && (num8%2)!=0 && (num9%2)!=0 && (num10%2)!=0  ){
        
            int i;
            for (i=0;i==1;i=i+1){
            int resultado;
            resultado= num1 + num2 +num3 +num4 + num5 + num6 + num7 + num8 + num9 + num10;
                System.out.println("la suma de los numeros impares es " + resultado);
            }
            
        }
        else {
            System.out.println("ingrese bien los numeros impares");
        }
    }
    
    
    public static void ejercicio3 (){
        //Registrar una cantidad determinada de trabajadores: nombre y salario. Luego, calcular el promedio de los salarios.
        Scanner obj=new Scanner (System.in);
        int trabajador;
        int resultado=0;
        for (trabajador=0;trabajador<=4;trabajador=trabajador+1){
            System.out.println("bienvenido señor(a) por favor escribe su nombre");
            String nombre=obj.next();
            System.out.println("favor de ingresar su salario");
            int salario=obj.nextInt();
            resultado= resultado+salario;
            
        }
        int promedio ;
       promedio= resultado /5;
        System.out.println("el promedio del salario de los trabajadores es de " + promedio);
    }
    
    
    public static void ejercicio4 (){
        //Dadas las edades y alturas de 5 alumnos, mostrar la edad y la estatura media, la cantidad de alumnos mayores de 18 años, y la cantidad de alumnos que miden más de 1.75.
        Scanner obj;
        obj=new Scanner (System.in);
        int i;
        int altura=0;
        int altura1=0; //para los mayores de 1.75        
        int edad=0;
        int edad1=0; //para los mayoes de 18 años
        for (i=0;i<=3;i=i+1){
            System.out.println("bienvenido favor de escribir su edad");
            edad=obj.nextInt();
            obj.nextLine();
            if (edad>=18){
                edad1++;
            }
           
            System.out.println ("bienvenido , favor de escribir su altura (sin valores decimales)");
            altura=obj.nextInt();
            obj.nextLine ();
            if (altura>=175){
                altura1++;
            }
           
            
          
            }
            System.out.println ("los alumnos que miden mas de 1.75 son " +  altura1);
            System.out.println("loa alumnos que tienen una edad de 18 años son " + altura1);
            
    }
}
